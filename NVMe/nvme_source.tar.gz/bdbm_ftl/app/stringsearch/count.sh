grep -Ro $1 $2 | wc -w
