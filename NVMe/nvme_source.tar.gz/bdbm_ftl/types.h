#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef unsigned long uint64_t;
typedef unsigned int uint32_t;
typedef unsigned char uint8_t;
