sudo insmod bdbm_drv.ko
