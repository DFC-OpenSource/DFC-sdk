sudo mount \-t ext4 \-o discard /dev/blueDBM /media/blueDBM
