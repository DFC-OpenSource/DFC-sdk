sudo ./bdbm_format /dev/blueDBM
sudo mkfs -t ext4 -b 4096 /dev/blueDBM
