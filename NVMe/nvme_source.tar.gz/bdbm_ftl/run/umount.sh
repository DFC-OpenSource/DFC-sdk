sudo umount /media/blueDBM
sudo rmmod bdbm_drv
