Readme :
--------
    => This application is carrying out the NVMe DDR and NAND I/O operation. 

Features Supported:
-------------------

1. Added NAND 16K page support.
2. Added QDMA support

Mistakes Corrected:
-------------------

=> Fixed DDR hang issue while doing mkfs
=> Fixed NAND timeout issue
=> Fixed Read-Trim Command issue

Performance:
------------

Read DDR speed          => 450 MBps
Write DDR speed         => 500 MBps
Read NAND speed         => 57 MBps
Write NAND speed        => 56 MBps


FPGA image version  => 02.05.02
