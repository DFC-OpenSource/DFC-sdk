
#ifndef __QDMA_H
#define __QDMA_H

#include <stdio.h>

#define QDMA_AVAIL	0x1
#define QDMA_ACCESSED	0x2
#define QDMA_FILLED	0x4
#define QDMA_POSTED	0x8
#define IO_TABLE_SIZE	512

struct qdma_io
{
    volatile struct qdma_desc *q_desc[128];
    volatile void *req;
    volatile struct timeval   io_post_time;
    volatile uint64_t cache_idx;
    volatile int    volatile count;
    volatile unsigned int status;
    volatile  int chan_no;
    pthread_mutex_t qdesc_mutex;
};

typedef struct QdmaCtrl
{
	volatile struct qdma_io des_io_table[IO_TABLE_SIZE];
	struct timeval time1;
	struct timeval time2;
	int volatile producer_index;
	int volatile consumer_index;
	int volatile qdma_io_posted;
	int volatile qdma_io_completed;
	int volatile pi_cnt;
	int volatile ci_cnt;
	int dev_error;
	int volatile size_counters[QDMA_DESC_COUNT];
	pthread_mutex_t qdma_mutex;
} QdmaCtrl;


void *io_completer_qdma(void *arg);

#ifdef QDMA
//int ramdisk_prp_rw_prologue(NvmeRequest *req, uint64_t idx);
int avail_qdma_desc(uint32_t nlb);
void ramdisk_prp_rw_epilogue();
#endif

#endif
