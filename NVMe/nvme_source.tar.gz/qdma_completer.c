#include<stdio.h>
#include <stdint.h>
#include<signal.h>
#include<sys/mman.h>
#include <mqueue.h>
#include <stdlib.h>
#include <unistd.h>
#include<sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <syslog.h>

#include "nvme.h"
#include"qdma.h"
#include"qdma_user_space_lib.h"
#include "ls2_cache.h"

#define TIMEOUT 10000000 

#ifdef QDMA

QdmaCtrl *g_QdmaCtrl;

void init_qdma_desc(NvmeCtrl *n)
{
	int i = 0;
	QdmaCtrl *qdma = &n->qdmactrl;
	g_QdmaCtrl = qdma;

	for(i=0;i<IO_TABLE_SIZE;i++) {
		qdma->des_io_table[i].status = QDMA_AVAIL;
		mutex_init((pthread_mutex_t *)&qdma->des_io_table[i].qdesc_mutex, NULL);
	}
	qdma->producer_index = 0;
	qdma->consumer_index = 0;
	qdma->qdma_io_posted = 0;
	qdma->qdma_io_completed = 0;
	qdma->pi_cnt = 0;
	qdma->ci_cnt = 0;
	qdma->dev_error = 0;
	mutex_init(&qdma->qdma_mutex, NULL);
}

int ramdisk_prp_rw_prologue(NvmeRequest *req, uint64_t idx)
{
	QdmaCtrl *qdma = g_QdmaCtrl;

	struct qdma_io *temp = (struct qdma_io *)(&qdma->des_io_table[qdma->producer_index]);

	if(temp->status == QDMA_AVAIL) {
		temp->count = 0;
		temp->req = (void *)req;
		temp->cache_idx = idx;
		temp->status = QDMA_ACCESSED;
		return 1;
	}

	return 0;
}

int avail_qdma_desc(uint32_t nlb)
{
	QdmaCtrl *qdma = g_QdmaCtrl;

	int diff = qdma->producer_index - qdma->consumer_index;

	diff = (diff < 0) ? (-1 * diff) : diff;
	if ((128 - diff) >= nlb) {
		return 1;
	}
	return 0;
}

void ramdisk_prp_rw_epilogue()
{
	QdmaCtrl *qdma = g_QdmaCtrl;

	struct qdma_io *temp = (struct qdma_io *)(&qdma->des_io_table[qdma->producer_index]);
	gettimeofday((struct timeval *)(&temp->io_post_time), NULL);
	temp->status = QDMA_POSTED;
	qdma->producer_index = (qdma->producer_index + 1) % IO_TABLE_SIZE;

	qdma->qdma_io_posted++;

}

long long int diff_time(struct timeval *newtime,struct timeval *oldtime)
{
	long long int var1,var2,diff;
	var1 = 1000000*(newtime->tv_sec) + (newtime->tv_usec);
	var2 = 1000000*(oldtime->tv_sec) + (oldtime->tv_usec);

	if(var1 >= var2) {
		diff = var1 - var2;
	}
	else {
		diff = var2 - var1;
	}
	return diff;
}

void alarm_handler(int sig)
{
	int i = 0;
	QdmaCtrl *qdma = g_QdmaCtrl;

	printf("p[i]: %d, c[i]: %d, p[s]: %d, c[s]: %d\n",qdma->producer_index,qdma->consumer_index,qdma->des_io_table[qdma->producer_index].status,qdma->des_io_table[qdma->consumer_index].status);

	printf("niop: %d, nioc: %d, tiop: %d, tioc: %d\n",qdma->qdma_io_posted,qdma->qdma_io_completed,qdma->pi_cnt,qdma->ci_cnt);
	for(i = 0;i < QDMA_DESC_COUNT;i++) {
		//syslog(LOG_INFO,"size_counters[%d]: %d\n",i,size_counters[i]);
	}
	printf("dev error: %d\n",qdma->dev_error);
	alarm(50);
}

void display()
{
	QdmaCtrl *qdma = g_QdmaCtrl;
	int i = 0;
	int c = qdma->consumer_index;

	printf("disp: count: %d\n",qdma->des_io_table[c].count);
	for(i = 0;i < qdma->des_io_table[c].count;i++) {
		printf("src: %lx, dest: %lx, len: %x, status: %d\n", 
				qdma->des_io_table[c].q_desc[i]->src_addr,qdma->des_io_table[c].q_desc[i]->dest_addr, 
				qdma->des_io_table[c].q_desc[i]->len,qdma->des_io_table[c].q_desc[i]->status);

	}

}

void cleanup_io(struct qdma_io *temp, int start)
{
	int i = 0;
	QdmaCtrl *qdma = g_QdmaCtrl;

	for(i = start;i < temp->count; i++) {
		qdma_desc_release(temp->q_desc[i]);
	}
	qdma->ci_cnt += temp->count;
}

int check_status(struct qdma_io *temp)
{
	int i;
	for(i = 0; i < temp->count; i++) {
		if(temp->q_desc[i]->status != DMA_DONE) {
			return -1;
		}
	}
	return 0;
}
#endif

void *qdma_completer(void *arg)
{
	NvmeCtrl *n = (NvmeCtrl *)arg;
	int ret = 0, i=0;

	set_thread_affinity(5, pthread_self());
#ifdef DDR_CACHE
	LS2_Cache *cache = &n->ls2_cache;
	struct mq_attr attr;
#endif

#ifndef QDMA
#ifdef DDR_CACHE
	Cache_DDR *ddr_cache = cache->ddr_table;
	uint8_t *dma_stat = cache->qDMA_status; 
	uint32_t tail_idx = 0;
	uint32_t nr_pages = cache->nr_pages_in_cache;
	nvme_bio *r_bio = NULL;
	int is_copied = 0;

#endif
#else
	QdmaCtrl *qdma = &n->qdmactrl;
	int sleep_time = 1;
	struct qdma_io *temp = NULL;
	long long int diff = 0;

	int timedout,io_completed;
	init_qdma_desc(n);
	signal(SIGALRM,alarm_handler);
	alarm(30);
	printf("%s: initialized qdma desc\n",__func__);
#endif

	while(1) {

#ifdef QDMA
		temp = (struct qdma_io *)(&qdma->des_io_table[qdma->consumer_index]);
		mutex_lock(&temp->qdesc_mutex);
		if (temp->status == QDMA_POSTED) {
			do {
				io_completed = !check_status(temp);
				if (io_completed) break;
				gettimeofday(&qdma->time2,NULL);
				diff = diff_time(&qdma->time2,(struct timeval *)&(temp->io_post_time));
				timedout = diff > TIMEOUT ? 1 : 0 ;
				usleep(sleep_time);
			} while (!timedout && !io_completed);/*try until timedout and io is not completed*/
			ret = 0;
			if(!io_completed) {
				qdma->dev_error++;            
				display();
				for (i=0; i<temp->count; i++) {
					if(temp->q_desc[i]->status != DMA_DONE) {
						uint64_t *saddr = NULL, *daddr = NULL;

						int fd = open (DEV_MEM, O_RDWR | O_SYNC);
						if (fd < 0) {
							perror(DEV_MEM);
						}

						saddr = (uint64_t *)mmap (0, getpagesize(), PROT_READ|PROT_WRITE, MAP_SHARED, fd, temp->q_desc[i]->src_addr);
						if(saddr == (uint64_t *)MAP_FAILED) {
							perror("mmap");
							close(fd);
							fd = 0;
						}
						daddr = (uint64_t *)mmap (0, getpagesize(), PROT_READ|PROT_WRITE, MAP_SHARED, fd, temp->q_desc[i]->dest_addr);
						if(saddr == (uint64_t *)MAP_FAILED) {
							perror("mmap");
							close(fd);
							fd = 0;
						}
						memcpy(daddr, saddr, temp->q_desc[i]->len);
						munmap ((void*)((uint64_t)saddr & 0xFFFFFFFFFFFFF000), getpagesize());
						munmap ((void*)((uint64_t)daddr & 0xFFFFFFFFFFFFF000), getpagesize());
						close (fd);
						temp->q_desc[i]->status = DMA_DONE;

					}
				}
			}
			cleanup_io(temp, 0);
			if (temp->req) {
#ifdef DDR_CACHE
				nvme_bio *bio = &(((NvmeRequest *)(temp->req))->bio); 
				if (n->target.mem_type[bio->ns_num] & FPGA_NAND_NS) {
					update_lba_table(cache, bio, temp->cache_idx);
				}
#endif
				nvme_rw_cb((void *)temp->req, ret);
			}
			//mutex_lock(&temp->qdesc_mutex);
			temp->status = QDMA_AVAIL;
			mutex_unlock(&temp->qdesc_mutex);
			qdma->consumer_index =  (qdma->consumer_index + 1) % IO_TABLE_SIZE;
			qdma->qdma_io_completed++;
		} else {
			mutex_unlock(&temp->qdesc_mutex);
			usleep(1);
		}
#else
#ifdef DDR_CACHE
		mutex_lock(&cache->qDMA_mutex);
		is_copied = (dma_stat[tail_idx] == COPIED) ? 1 : 0;
		mutex_unlock(&cache->qDMA_mutex);

		if (is_copied) {

			mutex_lock(&cache->cache_ddr_mutex);
			r_bio = ddr_cache[tail_idx].bio;
			mutex_unlock(&cache->cache_ddr_mutex);
			if(r_bio != NULL) {
				add_to_list(cache, (nvme_bio *)r_bio);
				nvme_rw_cb(r_bio->req_info, 0);
			}

			mutex_lock(&cache->qDMA_mutex);
			dma_stat[tail_idx] = FREE;
			mutex_unlock(&cache->qDMA_mutex);
			CIRCULAR_INCR (tail_idx, nr_pages);
		}
#endif
#endif
#ifdef DDR_CACHE
		ret = mq_getattr(n->nand_mq_txid, &attr);
		if((!ret) && (!attr.mq_curmsgs) && cache->head) {
			nvme_bio *bio = remove_from_list(cache);
			if (bio) {
				flash_to_nand(cache, bio, n->nand_mq_txid);
			}
		}
#endif
	}
}

