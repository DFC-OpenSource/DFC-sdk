
#ifndef __DMA_NAND_H
#define __DMA_NAND_H

#include <stdint.h>

typedef struct nand_bio {
	/*Fill the structure -TODO*/
} nand_bio;

typedef struct NandDmaDesc {
	/*Fill the structure -TODO*/
	uint64_t cmd_ptr;
} NandDmaDesc;

#endif /*#ifndef __DMA_NAND_H*/

