/* Copyright 2014 Freescale Semiconductor, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *	 notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *	 notice, this list of conditions and the following disclaimer in the
 *	 documentation and/or other materials provided with the distribution.
 *     * Neither the name of Freescale Semiconductor nor the
 *	 names of its contributors may be used to endorse or promote products
 *	 derived from this software without specific prior written permission.
 *
 *
 * ALTERNATIVELY, this software may be distributed under the terms of the
 * GNU General Public License ("GPL") as published by the Free Software
 * Foundation, either version 2 of that License or (at your option) any
 * later version.
 *
 * THIS SOFTWARE IS PROVIDED BY Freescale Semiconductor ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Freescale Semiconductor BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#define ECHO_BUFFER_SIZE  1024

static char echo_buffer[ECHO_BUFFER_SIZE];


/* echo_server : basic TCP server that accepts 1 connection.  Once a connection
   is received any data read from the socket is displayed and send back to the
   original sender
*/

int main(int argc, char **argv)
{
	int port = 0;
	int listen_socket;
	int echo_socket;
	struct sockaddr_in addr;
	int ret;
	int connected;
	int remaining_bytes, pos;

	if (argc != 2) {
		printf("Usage: %s <port>\n", argv[0]);
		return 1;
	}
	sscanf(argv[1], "%d", &port);
	if (port == 0) {
		printf("Unable to pasre port %s\n", argv[1]);
		return 1;
	}

	listen_socket = socket(AF_INET, SOCK_STREAM, 0);
	if (listen_socket < 0 ) {
		perror("socket() call for listen failed\n");
		return 1;
	}

	/* Allow ports to be reused */
	int yes = 1;
	if (setsockopt(listen_socket, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int))) {
		perror("setsockopt() failed");
		return 1;
	}
	memset(&addr, 0, sizeof(addr));
	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = htonl(INADDR_ANY);
	addr.sin_port = htons(port);

        if (bind(listen_socket, (struct sockaddr *)&addr, sizeof(addr))) {
		perror("Failed to bind to listening address");
		return 1;
	}

	if (listen(listen_socket, 1)) {
		perror("listen() failed");
		return 1;
	}
	while (1) {
		printf("Waiting for connection on port %d\n",  port);
		echo_socket = accept(listen_socket, NULL, NULL);
		if (echo_socket < 0) {
			perror("accept() failed");
			return 1;
		}
		printf("Connection established\n");
		connected = 1;
		while (connected) {
			ret = read(echo_socket, echo_buffer,
				   ECHO_BUFFER_SIZE -1);
			if (ret <= 0) {
				printf("Connection closed while reading\n");
				connected = 0;
				break;
			}
			echo_buffer[ret] = 0; /* Ensure Null Termination */
			printf("Echoing %d bytes : %s", ret, echo_buffer);
			remaining_bytes = ret;
			pos = 0;
			while (remaining_bytes > 0) {
				ret = write(echo_socket, &echo_buffer[pos],
							 remaining_bytes);
				if (ret < 0) {
					perror("write() failed");
					connected = 0;
					break;
				}
				pos += ret;
				remaining_bytes -= ret;
			}; /* End write loop */
		}; /* End connected loop */
	}; /* End accept loop */
	return 0;
}
